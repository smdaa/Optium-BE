# Documentation des fonctions

Documentation de toute les fonctions du package Optinum

```@index
Pages = ["fct_index.md"]
```

```@autodocs
Modules = [Optinum]
Order   = [:function, :type]
```
